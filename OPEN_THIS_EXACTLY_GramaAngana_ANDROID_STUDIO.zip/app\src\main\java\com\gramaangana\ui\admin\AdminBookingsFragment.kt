package com.gramaangana.ui.admin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.gramaangana.R
import com.gramaangana.data.FirebaseHelper
import com.gramaangana.databinding.FragmentAdminBookingsBinding
import com.gramaangana.databinding.ItemAdminBookingBinding
import com.gramaangana.model.Booking
import com.gramaangana.utils.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AdminViewModel : ViewModel() {
    private val _pendingBookings = MutableStateFlow<List<Booking>>(emptyList())
    val pendingBookings: StateFlow<List<Booking>> = _pendingBookings

    private val _allBookings = MutableStateFlow<List<Booking>>(emptyList())
    val allBookings: StateFlow<List<Booking>> = _allBookings

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    fun loadBookings() {
        viewModelScope.launch {
            _isLoading.value = true
            val bookings = FirebaseHelper.getBookings()
            _allBookings.value = bookings
            _pendingBookings.value = bookings.filter { it.status == "PENDING" }
            _isLoading.value = false
        }
    }

    fun updateBookingStatus(
        bookingId: String,
        status: String,
        keyHolder: String = "",
        onResult: (Boolean) -> Unit
    ) {
        viewModelScope.launch {
            val result = FirebaseHelper.updateBookingStatus(bookingId, status, keyHolder)
            loadBookings()
            onResult(result.isSuccess)
        }
    }
}

class AdminBookingsFragment : Fragment() {
    private var _binding: FragmentAdminBookingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AdminViewModel by viewModels()
    private lateinit var pendingAdapter: AdminBookingAdapter
    private lateinit var allAdapter: AdminBookingAdapter
    private var showPendingOnly = true

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAdminBookingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerViews()
        setupTabButtons()
        setupObservers()
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.loadBookings()
            binding.swipeRefresh.isRefreshing = false
        }
        viewModel.loadBookings()
    }

    override fun onResume() {
        super.onResume()
        viewModel.loadBookings()
    }

    private fun setupRecyclerViews() {
        pendingAdapter = AdminBookingAdapter(
            onApprove = { showApproveDialog(it) },
            onReject = { showRejectDialog(it) }
        )
        allAdapter = AdminBookingAdapter(
            onApprove = { showApproveDialog(it) },
            onReject = { showRejectDialog(it) }
        )
        binding.rvBookings.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = pendingAdapter
        }
    }

    private fun setupTabButtons() {
        binding.btnPending.setOnClickListener {
            showPendingOnly = true
            binding.rvBookings.adapter = pendingAdapter
            updateEmptyState()
        }
        binding.btnAll.setOnClickListener {
            showPendingOnly = false
            binding.rvBookings.adapter = allAdapter
            updateEmptyState()
        }
    }

    private fun setupObservers() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.isLoading.collect { loading ->
                binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.pendingBookings.collect { bookings ->
                pendingAdapter.submitList(bookings)
                binding.tvPendingCount.text = "${bookings.size} pending requests"
                updateEmptyState()
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.allBookings.collect { bookings ->
                allAdapter.submitList(bookings)
                updateEmptyState()
            }
        }
    }

    private fun updateEmptyState() {
        val isEmpty = if (showPendingOnly) {
            viewModel.pendingBookings.value.isEmpty()
        } else {
            viewModel.allBookings.value.isEmpty()
        }
        binding.tvEmpty.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.rvBookings.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

    private fun showApproveDialog(booking: Booking) {
        val input = EditText(requireContext()).apply {
            hint = "Key holder name"
            setPadding(48, 24, 48, 24)
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Approve Booking")
            .setMessage(
                "Approve booking for ${booking.requesterName}?\n" +
                    "Date: ${DateUtils.formatDate(booking.date)}\n" +
                    "Time: ${DateUtils.formatTime(booking.startTime)} - ${DateUtils.formatTime(booking.endTime)}"
            )
            .setView(input)
            .setPositiveButton("Approve") { _, _ ->
                viewModel.updateBookingStatus(booking.id, "APPROVED", input.text.toString().trim()) { success ->
                    Toast.makeText(requireContext(), if (success) "Booking approved" else "Approval failed", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showRejectDialog(booking: Booking) {
        AlertDialog.Builder(requireContext())
            .setTitle("Reject Booking")
            .setMessage("Reject booking for ${booking.requesterName}?")
            .setPositiveButton("Reject") { _, _ ->
                viewModel.updateBookingStatus(booking.id, "REJECTED") { success ->
                    Toast.makeText(requireContext(), if (success) "Booking rejected" else "Reject failed", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class AdminBookingAdapter(
    private val onApprove: (Booking) -> Unit,
    private val onReject: (Booking) -> Unit
) : ListAdapter<Booking, AdminBookingAdapter.ViewHolder>(DIFF) {

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Booking>() {
            override fun areItemsTheSame(a: Booking, b: Booking) = a.id == b.id
            override fun areContentsTheSame(a: Booking, b: Booking) = a == b
        }
    }

    inner class ViewHolder(val binding: ItemAdminBookingBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemAdminBookingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val booking = getItem(position)
        val ctx = holder.itemView.context
        holder.binding.apply {
            tvRequesterName.text = booking.requesterName.ifBlank { "Community member" }
            tvPhone.text = booking.requesterPhone.ifBlank { "No phone provided" }
            tvPurpose.text = booking.purpose.ifBlank { "Community hall booking" }
            tvEventType.text = booking.eventType.ifBlank { "General" }
            tvDate.text = "Date: ${DateUtils.formatDate(booking.date)}"
            tvTime.text = "Time: ${DateUtils.formatTime(booking.startTime)} - ${DateUtils.formatTime(booking.endTime)}"
            tvAttendees.text = "${booking.attendeeCount} attendees"
            tvNotes.visibility = if (booking.notes.isNotEmpty()) View.VISIBLE else View.GONE
            tvNotes.text = "Notes: ${booking.notes}"
            tvStatus.text = when (booking.status) {
                "APPROVED" -> "Approved"
                "PENDING" -> "Pending"
                "REJECTED" -> "Rejected"
                else -> booking.status
            }
            tvStatus.setTextColor(
                ContextCompat.getColor(
                    ctx,
                    when (booking.status) {
                        "APPROVED" -> R.color.status_free
                        "PENDING" -> R.color.status_pending
                        else -> R.color.status_booked
                    }
                )
            )
            layoutActions.visibility = if (booking.status == "PENDING") View.VISIBLE else View.GONE
            btnApprove.setOnClickListener { onApprove(booking) }
            btnReject.setOnClickListener { onReject(booking) }
            tvKeyHolder.visibility = if (booking.keyHolder.isNotEmpty()) View.VISIBLE else View.GONE
            tvKeyHolder.text = "Key holder: ${booking.keyHolder}"
        }
    }
}
