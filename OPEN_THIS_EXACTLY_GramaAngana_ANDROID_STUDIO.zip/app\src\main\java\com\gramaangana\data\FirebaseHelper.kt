package com.gramaangana.data

import android.content.Context
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.gramaangana.GramaAnganaApp
import com.gramaangana.model.Booking
import com.gramaangana.model.CommunityEvent
import com.gramaangana.model.MaintenanceItem
import com.gramaangana.model.Pledge
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object FirebaseHelper {
    private const val LOCAL_BOOKINGS_KEY = "bookings"

    private val db: FirebaseFirestore get() = Firebase.firestore
    private val prefs by lazy {
        GramaAnganaApp.instance.getSharedPreferences("LocalBookingCache", Context.MODE_PRIVATE)
    }

    suspend fun getBookings(): List<Booking> {
        val remoteBookings = getRemoteBookings()
        val localBookings = getLocalBookings()
        return (remoteBookings + localBookings)
            .associateBy { it.id }
            .values
            .sortedWith(compareBy<Booking> { it.date }.thenBy { it.startTime })
    }

    private suspend fun getRemoteBookings(): List<Booking> {
        return try {
            val snapshot = db.collection("bookings").get().await()
            snapshot.documents.mapNotNull { doc ->
                doc.toObject(Booking::class.java)?.copy(id = doc.id)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getBookingsByDate(date: String): List<Booking> {
        return getBookings().filter { it.date == date }
    }

    suspend fun submitBooking(booking: Booking): Result<String> {
        val approvedBookings = getBookingsByDate(booking.date).filter { it.status == "APPROVED" }
        val hasConflict = approvedBookings.any {
            val start = it.startTime.ifBlank { "00:00" }
            val end = it.endTime.ifBlank { "00:00" }
            !(booking.endTime <= start || booking.startTime >= end)
        }

        if (hasConflict) {
            return Result.failure(Exception("This time slot is already booked!"))
        }

        val pendingBooking = booking.copy(
            id = booking.id.ifBlank { "local-${UUID.randomUUID()}" },
            status = "PENDING",
            keyHolder = ""
        )

        return try {
            val data = hashMapOf(
                "requesterName" to pendingBooking.requesterName,
                "requesterPhone" to pendingBooking.requesterPhone,
                "purpose" to pendingBooking.purpose,
                "eventType" to pendingBooking.eventType,
                "date" to pendingBooking.date,
                "startTime" to pendingBooking.startTime,
                "endTime" to pendingBooking.endTime,
                "attendeeCount" to pendingBooking.attendeeCount,
                "status" to "PENDING",
                "notes" to pendingBooking.notes,
                "keyHolder" to ""
            )
            val ref = db.collection("bookings").add(data).await()
            saveLocalBooking(pendingBooking.copy(id = ref.id))
            Result.success(ref.id)
        } catch (e: Exception) {
            saveLocalBooking(pendingBooking)
            Result.success(pendingBooking.id)
        }
    }

    suspend fun updateBookingStatus(
        bookingId: String,
        status: String,
        keyHolder: String = ""
    ): Result<Unit> {
        updateLocalBooking(bookingId, status, keyHolder)
        return try {
            val updates = mutableMapOf<String, Any>("status" to status)
            if (keyHolder.isNotEmpty()) updates["keyHolder"] = keyHolder
            db.collection("bookings").document(bookingId).update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            if (bookingId.startsWith("local-")) Result.success(Unit) else Result.failure(e)
        }
    }

    private fun getLocalBookings(): List<Booking> {
        val raw = prefs.getString(LOCAL_BOOKINGS_KEY, "[]") ?: "[]"
        val array = JSONArray(raw)
        return (0 until array.length()).map { index ->
            array.getJSONObject(index).toBooking()
        }
    }

    private fun saveLocalBooking(booking: Booking) {
        val merged = (getLocalBookings().filterNot { it.id == booking.id } + booking)
            .sortedWith(compareBy<Booking> { it.date }.thenBy { it.startTime })
        saveLocalBookings(merged)
    }

    private fun updateLocalBooking(bookingId: String, status: String, keyHolder: String) {
        val updated = getLocalBookings().map {
            if (it.id == bookingId) it.copy(status = status, keyHolder = keyHolder) else it
        }
        saveLocalBookings(updated)
    }

    private fun saveLocalBookings(bookings: List<Booking>) {
        val array = JSONArray()
        bookings.forEach { array.put(it.toJson()) }
        prefs.edit().putString(LOCAL_BOOKINGS_KEY, array.toString()).apply()
    }

    private fun Booking.toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("requesterName", requesterName)
        put("requesterPhone", requesterPhone)
        put("purpose", purpose)
        put("eventType", eventType)
        put("date", date)
        put("startTime", startTime)
        put("endTime", endTime)
        put("attendeeCount", attendeeCount)
        put("status", status)
        put("notes", notes)
        put("keyHolder", keyHolder)
    }

    private fun JSONObject.toBooking(): Booking = Booking(
        id = optString("id"),
        requesterName = optString("requesterName"),
        requesterPhone = optString("requesterPhone"),
        purpose = optString("purpose"),
        eventType = optString("eventType"),
        date = optString("date"),
        startTime = optString("startTime"),
        endTime = optString("endTime"),
        attendeeCount = optInt("attendeeCount"),
        status = optString("status", "PENDING"),
        notes = optString("notes"),
        keyHolder = optString("keyHolder")
    )

    suspend fun getMaintenanceItems(): List<MaintenanceItem> {
        return try {
            val snapshot = db.collection("maintenance_items").get().await()
            snapshot.documents.mapNotNull { doc ->
                doc.toObject(MaintenanceItem::class.java)?.copy(id = doc.id)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun addPledge(itemId: String, pledge: Pledge): Result<Unit> {
        return try {
            val ref = db.collection("maintenance_items").document(itemId)
            db.runTransaction { transaction ->
                val snapshot = transaction.get(ref)
                val current = snapshot.getDouble("amountRaised") ?: 0.0
                transaction.update(ref, "amountRaised", current + pledge.amount)
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addMaintenanceItem(item: MaintenanceItem): Result<String> {
        return try {
            val data = hashMapOf(
                "title" to item.title,
                "description" to item.description,
                "amountNeeded" to item.amountNeeded,
                "amountRaised" to 0.0,
                "category" to item.category,
                "status" to "OPEN",
                "imageUrl" to ""
            )
            val ref = db.collection("maintenance_items").add(data).await()
            Result.success(ref.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getEvents(): List<CommunityEvent> {
        return try {
            val snapshot = db.collection("community_events").get().await()
            snapshot.documents.mapNotNull { doc ->
                doc.toObject(CommunityEvent::class.java)?.copy(id = doc.id)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getTodayEvents(today: String): List<CommunityEvent> {
        return try {
            val snapshot = db.collection("community_events")
                .whereEqualTo("date", today)
                .get()
                .await()
            snapshot.documents.mapNotNull { doc ->
                doc.toObject(CommunityEvent::class.java)?.copy(id = doc.id)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
